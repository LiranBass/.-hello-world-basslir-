from flask import Blueprint, render_template, flash
from flask import request, redirect, session
from utilities.db.db_manager import dbManager

# assignment10 blueprint definition
assignment10 = Blueprint('assignment10', __name__, static_folder='static', static_url_path='/assignment10',
                         template_folder='templates')


# Routes
@assignment10.route('/assignment10', methods=['GET', 'POST'])
def index():
    query_result = dbManager.fetch("select * from users")
    if request.method == 'POST':
        print(request.form['identify1'])
        if len(request.form['identify1']):
            first_name = request.form['first_name']
            identify1 = request.form['identify1']
            query = dbManager.commit("insert into users(identify1, first_name) VALUES ('%s', '%s')"
                                     % (request.form['identify1'], request.form['first_name']))
            flash('Your Account Inserted Successfully')
            query_result = dbManager.fetch("select * from users")
            return render_template('assignment10.html', users=query_result)
        if len(request.form['age']):
            age_n = request.form['age']
            id_age = request.form['iden']
            query_update = dbManager.commit(
                'update users set age=%s where identify1=%s', (age_n, id_age))
            query_result = dbManager.fetch("select * from users")
            flash('Your Account Age Updated Successfully')
            return render_template('assignment10.html', users=query_result)
    if request.method == 'GET':
        user_id = request.args.get('identify1')
        query = dbManager.commit("DELETE FROM USERS WHERE IDENTIFY1='%s'" % (user_id,))
        query_result = dbManager.fetch("select * from users")
        flash('Your Account Deleted Successfully')

        return render_template('assignment10.html', users=query_result)
    return render_template('assignment10.html', users=query_result)
