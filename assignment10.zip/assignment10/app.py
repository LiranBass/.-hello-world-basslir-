from flask import Flask, render_template, redirect, url_for
from flask import request, session
import mysql.connector
from utilities.db.db_manager import dbManager


###### App setup
app = Flask(__name__)
app.config.from_pyfile('settings.py')

###### Pages
## Homepage
from pages.homepage.homepage import homepage
app.register_blueprint(homepage)

## assignment10
from pages.assignment10.assignment10 import assignment10
app.register_blueprint(assignment10)

## About
from pages.about.about import about
app.register_blueprint(about)

## Catalog
from pages.catalog.catalog import catalog
app.register_blueprint(catalog)

# ## Page error handlers
# from pages.page_error_handlers.page_error_handlers import page_error_handlers
# app.register_blueprint(page_error_handlers)


###### Components
## Main menu
from components.main_menu.main_menu import main_menu
app.register_blueprint(main_menu)


if __name__ == '__main__':
    app.run(debug=True)
